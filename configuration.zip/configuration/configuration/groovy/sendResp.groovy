
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import java.util.Random;
import java.util.Arrays;
import java.util.List;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.*;

public class TransactionProcessor {

    public void process(Exchange exchange) throws Exception 
	{

        // Retrieve the incoming request body as a string
        String responseBody = exchange.getIn().getBody(String.class);
//	System.out.println("response body is :" +responseBody);
        // Parse the JSON string
       

        // Generate random values
        String CustomerId = responseBody.substring(665,695).trim();
        String ChannelRef = responseBody.substring(695,725).trim();
        String randomEfmsResponse = responseBody.substring(635,665).trim();
	String jsonResponse="";
	if(ChannelRef!=""){

        // Construct the JSON response as a String
        jsonResponse = String.format(
            "{\"Data\": {\"EFMSChannelReferenceNumber\": \"%s\", \"CustomerId\": \"%s\", \"EFMSResponse\": \"%s\"}}",
            ChannelRef, CustomerId, randomEfmsResponse
        );
	}
	else{
	jsonResponse = String.format(
            "{\"Data\": {\"CustomerId\": \"%s\", \"EFMSResponse\": \"%s\"}}",
             CustomerId, randomEfmsResponse
	 );
}
        // Set the JSON response as the exchange body
        exchange.getIn().setBody(jsonResponse);
    }

}
