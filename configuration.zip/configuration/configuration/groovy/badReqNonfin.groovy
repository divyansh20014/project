import org.apache.camel.Exchange;
import java.util.UUID;

public class badreq {

    // Method to generate the 400 error response if required fields are missing
    public void process(Exchange exchange) {
        // Generate a unique ID for the error
        String id = UUID.randomUUID().toString();
	System.out.println("Started the bad request bean");
        // Check which fields are missing
        StringBuilder errors = new StringBuilder();

        if (exchange.getIn().getHeader("CustomerId") == "") {
            errors.append("{\n" +
                    "    \"ErrorCode\": \"400\",\n" +
                    "    \"Message\": \"CustomerId is Required\",\n" +
                    "    \"Path\": \"/v1/evaluate-risk-nonfinancial\",\n" +
                    "    \"Url\": \"adbsfmdev.ondemand.sas.com\"\n" +
                    "},\n");
        }

        if (exchange.getIn().getHeader("EFMSChannelReferenceNumber") == "") {
            errors.append("{\n" +
                    "    \"ErrorCode\": \"400\",\n" +
                    "    \"Message\": \"EFMSChannelReferenceNumber is Required\",\n" +
                    "    \"Path\": \"/v1/evaluate-risk-nonfinancial\",\n" +
                    "    \"Url\": \"adbsfmdev.ondemand.sas.com\"\n" +
                    "},\n");
        }

        if (exchange.getIn().getHeader("Action") == "") {
            errors.append("{\n" +
                    "    \"ErrorCode\": \"400\",\n" +
                    "    \"Message\": \"Action is Required\",\n" +
                    "    \"Path\": \"/v1/evaluate-risk-nonfinancial\",\n" +
                    "    \"Url\": \"adbsfmdev.ondemand.sas.com\"\n" +
                    "}\n");
        }

        // If there are missing fields, build the error response
        if (errors.length() > 0) {
            // Remove the trailing comma
            if (errors.charAt(errors.length() - 2) == ',') {
                errors.delete(errors.length() - 2, errors.length());
            }

            // Construct the error response
            String errorResponse = "{\n" +
                    "    \"Code\": \"API400\",\n" +
                    "    \"Id\": \"" + id + "\",\n" +
                    "    \"Message\": \"Bad or Missing Request Parameters\",\n" +
                    "    \"Errors\": [\n" +
                    errors.toString() +
                    "    ]\n" +
                    "}";

            // Set the error response in the Exchange body
		System.out.println("The error response is "+errorResponse);
            exchange.getIn().setBody(errorResponse);
        }
    }
}