import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import java.util.Random;
import java.util.Arrays;
import java.util.List;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;

public class TransactionProcessor {

    private Random random = new Random();

    // Predefined EfmsResponse values
    private static final List<String> EFMS_RESPONSES = Arrays.asList("APPROVE", "DECLINE", "STEP-UP");

   
    public void process(Exchange exchange) throws Exception 
	{

        // Retrieve the incoming request body as a string
        String requestBody = exchange.getIn().getBody(String.class);

        // Parse the JSON string
        JSONObject jsonObject = new JSONObject(requestBody);

        // Generate random values
        String CustomerId = jsonObject.getJSONObject("Data").getString("CustomerId");
        String ChannelRef = jsonObject.getJSONObject("Data").getString("EFMSChannelReferenceNumber");
        String randomEfmsResponse = EFMS_RESPONSES.get(random.nextInt(EFMS_RESPONSES.size()));

        // Construct the JSON response as a String
        String jsonResponse = String.format(
            "\"Data\": {\"EFMSChannelReferenceNumber\": \"%s\", \"CustomerId\": \"%s\", \"EFMSResponse\": \"%s\"}",
            ChannelRef, CustomerId, randomEfmsResponse
        );

        // Set the JSON response as the exchange body
        exchange.getIn().setBody(jsonResponse);
    }

}