/*import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.json.JSONObject;
import java.io.*;
import java.net.*;
import java.nio.charset.*;

public class processTransaction{
    
    public void process(Exchange exchange) throws Exception {
        // Retrieve the incoming request body as a string
        String requestBody = exchange.getIn().getBody(String.class);

        // Parse the JSON string
        JSONObject jsonObject = new JSONObject(requestBody);

        // Extract transaction_type and transaction_id from the parsed JSON
        String transactionType = jsonObject.getString("transaction_type");
        String transactionId = jsonObject.getString("transaction_id");
		
		// Send a message to the server
		String message = jsonObject.getString("transaction_fixedlength");
        	System.out.println("Length of message recevied from AHB is : " + message.length());
		String serverAddress = "ahb02au";   // IP address of the server
        	int port = 5018;                    // Port on which the server is listening
		String responseFixedLength = "";
		
        try (Socket socket = new Socket("localhost", 5018);
             DataOutputStream out = new DataOutputStream(socket.getOutputStream());
             DataInputStream in = new DataInputStream(socket.getInputStream());
             ) {

            // Read message from the file

            if (message != null) {
                // Send the message using DataOutputStream
                out.writeUTF(message);
                out.flush();

                // Receive response using DataInputStream
int mesLength = 756;				
byte[] byteResponse = new byte[mesLength]
in.readFully(byteResponse);                
				String decodedString = new String(byteResponse, StandardCharsets.UTF_8);
				responseFixedLength = decodedString.replaceAll("[^a-zA-Z0-9\\s]", " ").substring(2);
				
                System.out.println("Server response: " + responseFixedLength);
            } else {
                System.out.println("The file is empty or not found.");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
		
        // Construct the response JSON
        JSONObject responseJson = new JSONObject();
        responseJson.put("transaction_type", transactionType);
        responseJson.put("transaction_id", transactionId);
        responseJson.put("response_fixedlength", responseFixedLength);

        // Set the JSON response as the exchange body
        exchange.getIn().setBody(responseJson);
    }
	
}*/


import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.json.JSONObject;
import java.io.*;
import java.net.*;
import java.nio.charset.*;

public class processTransaction{
    
    public void process(Exchange exchange) throws Exception {
        // Retrieve the incoming request body as a string
        String requestBody = exchange.getIn().getBody(String.class);

        // Parse the JSON string
        JSONObject jsonObject = new JSONObject(requestBody);

        // Extract transaction_type and transaction_id from the parsed JSON
        String transactionType = jsonObject.getString("transaction_type");
        String transactionId = jsonObject.getString("transaction_id");
	String CustomerId = jsonObject.optString("customer_id");	
		// Send a message to the server
		String message = jsonObject.getString("transaction_fixedlength");
        	System.out.println("Length of message recevied from AHB is : " + message.length());
		String serverAddress = "ahb02au";   // IP address of the server
        	int port = 5018;                    // Port on which the server is listening
		String responseFixedLength = "";
		
        try (Socket socket = new Socket("localhost", 5018);
             DataOutputStream out = new DataOutputStream(socket.getOutputStream());
             DataInputStream in = new DataInputStream(socket.getInputStream());
             ) {

            // Read message from the file

            if (message != null) {
                // Send the message using DataOutputStream
                out.writeUTF(message);
                out.flush();

                // Receive response using DataInputStream
int mesLength = 756;				
byte[] byteResponse = new byte[mesLength]
in.readFully(byteResponse);                
				String decodedString = new String(byteResponse, StandardCharsets.UTF_8);
				responseFixedLength = decodedString.replaceAll("[^a-zA-Z0-9\\s]", " ").substring(2);
				
                System.out.println("Server response: " + responseFixedLength);
            } else {
                System.out.println("The file is empty or not found.");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
		
        // Construct the response JSON
        JSONObject responseJson = new JSONObject();
        responseJson.put("transaction_type", transactionType);
        responseJson.put("transaction_id", transactionId);
	responseJson.put("customer_id", CustomerId);
        responseJson.put("response_fixedlength", responseFixedLength);

        // Set the JSON response as the exchange body
        exchange.getIn().setBody(responseJson);
    }
	
}
