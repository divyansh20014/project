

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.json.JSONObject;
import java.io.*;
import java.net.*;
import java.nio.charset.*;

public class processTransaction{
    
    public void process(Exchange exchange) throws Exception {
        // Retrieve the incoming request body as a string
        String requestBody = exchange.getIn().getBody(String.class);

        // Parse the JSON string
        JSONObject jsonObject = new JSONObject(requestBody);

        // Extract transaction_type and transaction_id from the parsed JSON
        String transactionType = jsonObject.getString("transaction_type");
        String transactionId = jsonObject.getString("transaction_id");
	String CustomerId = jsonObject.optString("customer_id");	
	
	exchange.getIn().setHeader("CustomerId", CustomerId);
	exchange.getIn().setHeader("transactionType", transactionType);
	exchange.getIn().setHeader("transactionId", transactionId);
		// Send a message to the server
		String message = jsonObject.getString("transaction_fixedlength");
        	System.out.println("Length of message recevied from AHB is : " + message.length());
		exchange.getIn.setBody(message);
		

    }
	
}