import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.json.JSONObject;
import java.io.*;
import java.net.*;
import java.nio.charset.*;

public class sendResp{
    
    public void process(Exchange exchange) throws Exception {
        // Retrieve the incoming request body as a string
        String response_fixedlength = exchange.getIn().getBody(String.class);
		String transactionId= exchange.getIn().getHeader("transactionId");
		String transactionType= exchange.getIn().getHeader("transactionType");
		String CustomerId= exchange.getIn().getHeader("CustomerId");

        // Parse the JSON string
        
		
		
        // Construct the response JSON
        JSONObject responseJson = new JSONObject();
        responseJson.put("transaction_type", transactionType);
        responseJson.put("transaction_id", transactionId);
		responseJson.put("customer_id", CustomerId);
        responseJson.put("response_fixedlength", response_FixedLength);

        // Set the JSON response as the exchange body
        exchange.getIn().setBody(responseJson);
    }
	
}
