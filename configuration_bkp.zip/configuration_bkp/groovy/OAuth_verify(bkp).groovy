import org.apache.camel.Exchange;
import java.util.*;

public class AuthTokenValidator {
    
    public void process(Exchange exchange) throws Exception {
        // Get the Authorization header
        String authHeader = exchange.getIn().getHeader("Authorization", String.class);

        if (authHeader != null && authHeader.startsWith("Bearer ")) {
            String token = authHeader.substring(7);

            // Here, validate the token (in a real scenario, you'd check a DB or cache)
            if (isValidToken(token)) {
                // Token is valid, proceed
                return;
            }
        }
        
        // If invalid, throw an exception
        throw new Exception("Invalid or missing token");
    }

    private boolean isValidToken(String token) {
        // For demonstration, accept any token that isn't null/empty
        return token != null && !token.isEmpty();
    }
}
